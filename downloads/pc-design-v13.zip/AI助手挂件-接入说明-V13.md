# 随身 AI 助手 · V13

将 AI助手挂件-V13.js 放入目标页面可以访问的静态资源目录。脚本使用 Shadow DOM 隔离样式；默认以右下角小太阳按钮收起显示。

```html
<script>
window.GXAI_CONFIG = {
  context: '资产管理系统',
  open: false,
  agentUrl: '/ai-agent',
  onAsk: ({ question, context }) => {
    // 对接业务系统会话服务；此演示组件仍显示固定示例回复。
  }
};
</script>
<script src="AI助手挂件-V13.js"></script>
```

页面内路由切换后，调用 GXAssistant.setContext('财务共享系统') 更新当前业务场景；对话保留在当前页面内存。还提供 open()、close()、ask('问题') 和 destroy()。脚本重复加载不会创建重复挂件。

可监听 gxai:ready、gxai:ask、gxai:expand 事件。事件携带问题与上下文（如适用）。示例没有网络请求，附件只在本地显示所选文件名，不上传。

真正跨系统保持同一会话，需要接入统一身份、会话存储与模型服务；当前组件完成可复用的前端外观和演示交互，不包含后端服务。页面刷新会重置示例会话。
